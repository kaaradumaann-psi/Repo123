"""
Constants package for OMRChecker.

"""
